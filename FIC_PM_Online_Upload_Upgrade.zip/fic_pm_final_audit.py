﻿import os
import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "Data")
REPORTS = os.path.join(BASE, "Reports")

checks = [
    ("Live Software", os.path.join(DATA, "live_software.csv")),
    ("Live Startup", os.path.join(DATA, "live_startup.csv")),
    ("Live USB", os.path.join(DATA, "live_usb.csv")),
    ("Live Prefetch", os.path.join(DATA, "live_prefetch_inventory.csv")),
    ("Live Features", os.path.join(DATA, "live_software_features.csv")),
    ("Live Detectors", os.path.join(REPORTS, "live_detector_results.csv")),
    ("Correlated Evidence", os.path.join(REPORTS, "live_correlated_evidence.csv")),
    ("Priority Output", os.path.join(REPORTS, "FIC_PM_LIVE_PRIORITY.csv")),
]

print("=" * 70)
print("FIC-PM FINAL SYSTEM INTEGRITY AUDIT")
print("=" * 70)

results = {}
for name, path in checks:
    if os.path.exists(path):
        try:
            df = pd.read_csv(path)
            results[name] = df
            print(f"[PASS] {name:22s} | {len(df):5d} records | {len(df.columns):3d} columns")
        except Exception as e:
            print(f"[FAIL] {name:22s} | Read error: {e}")
    else:
        print(f"[FAIL] {name:22s} | File missing")

print("\n" + "-" * 70)

# Record consistency
software_count = len(results["Live Software"]) if "Live Software" in results else -1

for name in ["Live Features", "Live Detectors", "Correlated Evidence", "Priority Output"]:
    if name in results:
        count = len(results[name])
        status = "PASS" if count == software_count else "FAIL"
        print(f"[{status}] {name} count: {count} | Expected: {software_count}")

# Required detector fields
if "Live Detectors" in results:
    required = ["IF_Flag", "LOF_Flag", "SVM_Flag", "Anomaly_Detector_Count"]
    missing = [c for c in required if c not in results["Live Detectors"].columns]
    print("[PASS] Detector columns complete" if not missing else f"[FAIL] Missing detector columns: {missing}")

# Priority checks
if "Priority Output" in results:
    p = results["Priority Output"]
    required = ["FIC_PM_Score", "Priority_Rank", "Priority_Level", "Review_Reason"]
    missing = [c for c in required if c not in p.columns]
    print("[PASS] Priority fields complete" if not missing else f"[FAIL] Missing priority fields: {missing}")

    if "FIC_PM_Score" in p:
        scores = pd.to_numeric(p["FIC_PM_Score"], errors="coerce")
        print("[PASS] Scores numeric" if scores.notna().all() else "[FAIL] Non-numeric scores found")
        print("Score range:", scores.min(), "to", scores.max())

# Dashboard and launcher
for name, path in [
    ("Dashboard", os.path.join(BASE, "fic_pm_dashboard_live.py")),
    ("Launcher", os.path.join(BASE, "RUN_FIC_PM.bat")),
]:
    print("[PASS]" if os.path.exists(path) else "[FAIL]", name, "exists" if os.path.exists(path) else "missing")

print("\nAUDIT FINISHED.")
