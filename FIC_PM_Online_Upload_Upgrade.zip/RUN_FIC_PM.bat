@echo off
cd /d "%~dp0"
echo ==================================================
echo FIC-PM AUTOMATED FORENSIC INVESTIGATION PIPELINE
echo ==================================================

py fic_pm_live_collector.py
if errorlevel 1 goto error

py fic_pm_live_features.py
if errorlevel 1 goto error

py fic_pm_live_detectors.py
if errorlevel 1 goto error

py fic_pm_live_correlation.py
if errorlevel 1 goto error

py fic_pm_live_priority.py
if errorlevel 1 goto error

echo.
echo PIPELINE COMPLETED. LAUNCHING DASHBOARD...
echo.

py -m streamlit run fic_pm_dashboard_live.py
goto end

:error
echo.
echo PIPELINE FAILED. Check the error above.
pause

:end
