# FIC-PM
## Forensic Investigation & Corroboration – Priority Management

### 1. Project Overview
FIC-PM is a Windows forensic investigation assistance prototype designed to collect selected system artifacts, identify statistical anomalies, correlate available evidence, and rank artifacts for further manual investigation.

It provides investigation prioritization, not a malware verdict.

### 2. Evidence Collection
The live collector gathers:
- Installed software records from Windows uninstall registry entries.
- USB device records from USBSTOR registry entries.
- Startup entries from Run and RunOnce registry locations.
- Windows Prefetch file inventory.

### 3. Feature Engineering
Software metadata is converted into numerical features, including:
- Software name length
- Version availability
- Publisher availability
- Install date availability
- Install location availability
- Registry path length
- Registry source

### 4. Anomaly Detection
Three unsupervised anomaly detection algorithms are used:
- Isolation Forest
- Local Outlier Factor (LOF)
- One-Class Support Vector Machine (SVM)

Their outputs are combined with contextual evidence for investigation prioritization.

### 5. Evidence Correlation
Software records are correlated with startup and Prefetch records using name-based matching.

These matches are heuristic associations and do not establish confirmed execution or attribution.

### 6. Priority Scoring
The current experimental scoring model uses:
- Detector consensus: maximum 60 points
- Startup association: maximum 20 points
- Prefetch association: maximum 20 points

Metadata gaps are displayed separately and do not increase the score.

The score is a heuristic investigation-priority indicator, not a probability of malware or compromise. Weights and thresholds require further validation.

### 7. Dashboard
The Streamlit dashboard provides:
- Overview and priority distribution
- Prioritized investigation queue
- Detector analysis
- Startup and USB evidence
- Prefetch inventory

### 8. Installation
Install dependencies:

    SETUP_FIC_PM.bat

Or run:

    py -m pip install -r requirements.txt

### 9. Execution
Run the complete workflow:

    RUN_FIC_PM.bat

The launcher performs collection, feature generation, anomaly detection, evidence correlation, priority scoring, and dashboard launch.

### 10. Current Validation
The current system integrity audit verified:
- 197 software records
- 8 startup records
- 1 USBSTOR record
- 574 Prefetch inventory records
- 197 feature records
- 197 detector records
- 197 correlated evidence records
- 197 priority records

### 11. Limitations
- The current collector has not been validated across different Windows systems.
- USB collection is limited to the USBSTOR registry source.
- Prefetch collection currently inventories files; it does not parse detailed Prefetch execution information.
- Startup and Prefetch associations use heuristic matching.
- Anomaly detectors use limited software metadata features.
- Scoring weights and thresholds are experimental and require validation against independently labelled forensic datasets.
- Findings require manual forensic examination and corroboration.

### 12. Ethical and Forensic Use
Use only on systems for which you have authorization. Preserve original evidence, document collection procedures, and independently verify findings before drawing conclusions.

---
FIC-PM | Experimental Windows Forensic Investigation Prioritization Prototype


## 13. Online CSV Upload Dashboard (New)
The optional `fic_pm_dashboard_upload.py` provides an upload-based analysis mode:
- Upload `live_software.csv`, `live_usb.csv`, `live_startup.csv`, and `live_prefetch_inventory.csv`.
- The app validates required columns and runs feature engineering, IF/LOF/One-Class SVM, heuristic correlation, and the experimental 60/20/20 priority score on the uploaded dataset.
- Results are displayed in separate tabs and priority/detector CSV outputs can be downloaded.
- Uploaded records are processed in the running app session; this prototype does not provide a persistent case-management database or multi-user access control.

### Run the upload dashboard locally
    py -m pip install -r requirements.txt
    py -m streamlit run fic_pm_dashboard_upload.py

### Deploy with Streamlit Community Cloud
1. Create a GitHub repository for the online dashboard code.
2. Add `fic_pm_dashboard_upload.py`, `fic_pm_upload_engine.py`, and `requirements.txt`.
3. Do not commit endpoint evidence, `Data/`, `Reports/`, registry exports, device identifiers, or other private forensic records.
4. In Streamlit Community Cloud, deploy the repository and set the main file to `fic_pm_dashboard_upload.py`.
5. Share the resulting app URL with intended users, subject to the app's access settings.

For endpoint collection, the Windows user separately runs `COLLECT_FIC_PM.bat` from the project folder and uploads the four CSV files from `Data/` to the dashboard.

### Privacy warning
Forensic CSVs can contain installed software, registry paths, USB serial identifiers, usernames, and file paths. Do not upload real endpoint evidence to a public or unapproved hosted service. Use synthetic or sanitized data for demonstrations unless the device owner and your institution authorize the transfer and the hosting arrangement is appropriate.
