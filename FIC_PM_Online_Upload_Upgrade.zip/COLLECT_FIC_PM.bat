@echo off
cd /d "%~dp0"
echo FIC-PM Windows evidence collection
py fic_pm_live_collector.py
if errorlevel 1 (
  echo Collection failed. Check Python and permissions.
  pause
  exit /b 1
)
echo.
echo CSV files created in the Data folder.
echo Upload these four files to the FIC-PM online dashboard:
echo live_software.csv
echo live_usb.csv
echo live_startup.csv
echo live_prefetch_inventory.csv
pause
