﻿import os
import re
import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "Data")
REPORTS = os.path.join(BASE, "Reports")

os.makedirs(REPORTS, exist_ok=True)

software = pd.read_csv(os.path.join(DATA, "live_software.csv")).fillna("")
startup = pd.read_csv(os.path.join(DATA, "live_startup.csv")).fillna("")
usb = pd.read_csv(os.path.join(DATA, "live_usb.csv")).fillna("")
prefetch = pd.read_csv(os.path.join(DATA, "live_prefetch_inventory.csv")).fillna("")
detectors = pd.read_csv(os.path.join(REPORTS, "live_detector_results.csv")).fillna("")

# Align detector results by original row order, not duplicate names
if len(software) != len(detectors):
    raise ValueError("Software/detector row count mismatch!")

detector_cols = [
    "IF_Flag", "LOF_Flag", "SVM_Flag",
    "Anomaly_Detector_Count", "Detector_Status"
]

for col in detector_cols:
    software[col] = detectors[col].values

def extract_exe(text):
    text = str(text)
    matches = re.findall(r'(?i)([a-z0-9_. -]+\.exe)', text)
    return [m.strip().strip('"').split("\\")[-1].lower() for m in matches]

def normalize(text):
    text = str(text).lower()
    text = re.sub(r'[^a-z0-9]', '', text)
    return text

# Startup executable evidence
startup_exes = []
for _, row in startup.iterrows():
    exes = extract_exe(row.get("Value_Data", ""))
    for exe in exes:
        startup_exes.append({
            "Startup_Name": row.get("Value_Name", ""),
            "Startup_Location": row.get("Location", ""),
            "Startup_Exe": exe,
            "Startup_Command": row.get("Value_Data", "")
        })

startup_exes = pd.DataFrame(startup_exes)

# Prefetch executable names (filename portion before hash)
prefetch_exes = []
for _, row in prefetch.iterrows():
    filename = str(row.get("File_Name", ""))
    exe_part = filename.split("-")[0].strip().lower()
    if exe_part.endswith(".pf"):
        exe_part = exe_part[:-3]
    prefetch_exes.append({
        "Prefetch_Exe": exe_part,
        "Prefetch_File": filename,
        "Prefetch_Path": row.get("File_Path", "")
    })

prefetch_exes = pd.DataFrame(prefetch_exes)

# Correlation using conservative name-based heuristics
startup_matches = []
prefetch_matches = []

for _, sw in software.iterrows():
    name = str(sw.get("Software_Name", ""))
    install_path = str(sw.get("Install_Location", ""))
    norm_name = normalize(name)

    # Startup match: software name or recognizable name fragment
    s_matches = []
    if not startup_exes.empty:
        for _, st in startup_exes.iterrows():
            exe = str(st["Startup_Exe"])
            exe_base = normalize(exe.replace(".exe", ""))
            if exe_base and len(exe_base) >= 4:
                if exe_base in norm_name or norm_name in exe_base:
                    s_matches.append(st["Startup_Exe"])

    # Prefetch: compare executable stem against software name
    p_matches = []
    if not prefetch_exes.empty:
        for _, pf in prefetch_exes.iterrows():
            exe = normalize(str(pf["Prefetch_Exe"]).replace(".exe", ""))
            if exe and len(exe) >= 4:
                if exe in norm_name or norm_name in exe:
                    p_matches.append(pf["Prefetch_File"])

    startup_matches.append(sorted(set(s_matches)))
    prefetch_matches.append(sorted(set(p_matches)))

software["Startup_Match_Count"] = [len(x) for x in startup_matches]
software["Startup_Matched_Executables"] = [
    "; ".join(x) for x in startup_matches
]
software["Prefetch_Match_Count"] = [len(x) for x in prefetch_matches]
software["Prefetch_Matched_Files"] = [
    "; ".join(x) for x in prefetch_matches
]

software["USB_Record_Count"] = len(usb)
software["Startup_Source_Record_Count"] = len(startup)
software["Prefetch_Source_Record_Count"] = len(prefetch)

software["Context_Evidence_Count"] = (
    (software["Startup_Match_Count"] > 0).astype(int) +
    (software["Prefetch_Match_Count"] > 0).astype(int)
)

software["Detector_Flag_Count"] = (
    software["Anomaly_Detector_Count"].fillna(0)
)

software["Evidence_Review_Indicator"] = (
    (software["Detector_Flag_Count"] > 0) |
    (software["Context_Evidence_Count"] > 0)
)

output = os.path.join(REPORTS, "live_correlated_evidence.csv")
software.to_csv(output, index=False)

print("=" * 65)
print("FIC-PM LIVE EVIDENCE CORRELATION")
print("=" * 65)
print("Software records:", len(software))
print("Startup source entries:", len(startup))
print("USB source entries:", len(usb))
print("Prefetch source files:", len(prefetch))
print("Software with startup name matches:", (software["Startup_Match_Count"] > 0).sum())
print("Software with Prefetch name matches:", (software["Prefetch_Match_Count"] > 0).sum())
print("Software with detector or contextual flags:", software["Evidence_Review_Indicator"].sum())

print("\nSample correlated records:")
cols = ["Software_Name", "Anomaly_Detector_Count",
        "Startup_Match_Count", "Prefetch_Match_Count",
        "Context_Evidence_Count", "Evidence_Review_Indicator"]
print(
    software.sort_values(
        ["Evidence_Review_Indicator", "Anomaly_Detector_Count"],
        ascending=False
    )[cols].head(15).to_string(index=False)
)

print("\nOutput:", output)
print("Correlation completed.")
print("Name-based matches are heuristic, not confirmed attribution.")
