﻿import os
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.svm import OneClassSVM

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "Data")
INPUT = os.path.join(DATA, "live_software_features.csv")
OUTPUT = os.path.join(BASE, "Reports", "live_detector_results.csv")

os.makedirs(os.path.join(BASE, "Reports"), exist_ok=True)

df = pd.read_csv(INPUT)

feature_columns = [
    "Name_Length",
    "Version_Present",
    "Publisher_Present",
    "Install_Date_Present",
    "Install_Location_Present",
    "Registry_Path_Length",
    "HKCU_Source",
    "HKLM_Source"
]

X = df[feature_columns].fillna(0)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Isolation Forest
if_model = IsolationForest(
    n_estimators=200,
    contamination=0.05,
    random_state=42
)
if_pred = if_model.fit_predict(X_scaled)

# Local Outlier Factor
lof_model = LocalOutlierFactor(
    n_neighbors=20,
    contamination=0.05
)
lof_pred = lof_model.fit_predict(X_scaled)

# One-Class SVM
svm_model = OneClassSVM(
    kernel="rbf",
    gamma="scale",
    nu=0.05
)
svm_pred = svm_model.fit_predict(X_scaled)

# Convert -1 anomaly and 1 normal into binary anomaly flags
df["IF_Flag"] = (if_pred == -1).astype(int)
df["LOF_Flag"] = (lof_pred == -1).astype(int)
df["SVM_Flag"] = (svm_pred == -1).astype(int)

df["Detector_Consensus"] = (
    df["IF_Flag"] + df["LOF_Flag"] + df["SVM_Flag"]
)

df["Anomaly_Detector_Count"] = (
    (df["IF_Flag"] == 1).astype(int) +
    (df["LOF_Flag"] == 1).astype(int) +
    (df["SVM_Flag"] == 1).astype(int)
)

df["Detector_Agreement"] = df["Anomaly_Detector_Count"] / 3

df["Detector_Status"] = df["Anomaly_Detector_Count"].map({
    0: "No detector flagged",
    1: "Single detector flag",
    2: "Two detector agreement",
    3: "Three detector agreement"
})

df.to_csv(OUTPUT, index=False)

print("=" * 60)
print("FIC-PM LIVE ANOMALY DETECTION")
print("=" * 60)
print("Total software:", len(df))
print("Isolation Forest flags:", df["IF_Flag"].sum())
print("LOF flags:", df["LOF_Flag"].sum())
print("One-Class SVM flags:", df["SVM_Flag"].sum())
print("Any detector flagged:", (df["Anomaly_Detector_Count"] > 0).sum())
print("All three agree:", (df["Anomaly_Detector_Count"] == 3).sum())

print("\nTop detector-agreement records:")
print(
    df.sort_values(
        ["Anomaly_Detector_Count", "Software_Name"],
        ascending=[False, True]
    )[[
        "Software_Name",
        "IF_Flag",
        "LOF_Flag",
        "SVM_Flag",
        "Anomaly_Detector_Count",
        "Detector_Status"
    ]].head(15).to_string(index=False)
)

print("\nOutput:", OUTPUT)
print("\nDetection completed.")
print("Detector flags indicate statistical outliers, not malware.")
