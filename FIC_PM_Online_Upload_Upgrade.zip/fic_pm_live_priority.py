﻿import os
import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
REPORTS = os.path.join(BASE, "Reports")

INPUT = os.path.join(REPORTS, "live_correlated_evidence.csv")
OUTPUT = os.path.join(REPORTS, "FIC_PM_LIVE_PRIORITY.csv")

df = pd.read_csv(INPUT).fillna("")

detector = pd.to_numeric(
    df["Anomaly_Detector_Count"], errors="coerce"
).fillna(0).clip(0, 3)

startup = pd.to_numeric(
    df["Startup_Match_Count"], errors="coerce"
).fillna(0)

prefetch = pd.to_numeric(
    df["Prefetch_Match_Count"], errors="coerce"
).fillna(0)

# Revised provisional score
df["Detector_Component"] = (detector / 3 * 60).round(2)
df["Startup_Component"] = (startup > 0).astype(int) * 20
df["Prefetch_Component"] = (prefetch > 0).astype(int) * 20

metadata_fields = ["Version", "Publisher", "Install_Date", "Install_Location"]
gap_count = 0

for field in metadata_fields:
    if field in df.columns:
        gap_count += df[field].astype(str).str.strip().eq("").astype(int)

df["Metadata_Gap_Count"] = gap_count

df["FIC_PM_Score"] = (
    df["Detector_Component"] +
    df["Startup_Component"] +
    df["Prefetch_Component"]
).round(2)

df["Priority_Rank"] = df["FIC_PM_Score"].rank(
    method="min", ascending=False
).astype(int)

df["Priority_Level"] = pd.cut(
    df["FIC_PM_Score"],
    bins=[-1, 19, 39, 69, 100],
    labels=["Routine", "Low", "Moderate", "High"]
).astype(str)

def reasons(row):
    items = []
    if row["Anomaly_Detector_Count"] > 0:
        items.append(f"Detector agreement: {int(row['Anomaly_Detector_Count'])}/3")
    if row["Startup_Match_Count"] > 0:
        items.append("Startup name association")
    if row["Prefetch_Match_Count"] > 0:
        items.append("Prefetch name association")
    if row["Metadata_Gap_Count"] > 0:
        items.append(f"Metadata gaps: {int(row['Metadata_Gap_Count'])}")
    return "; ".join(items) or "No indicators in current scoring inputs"

df["Review_Reason"] = df.apply(reasons, axis=1)

df = df.sort_values(
    ["FIC_PM_Score", "Software_Name"],
    ascending=[False, True]
).reset_index(drop=True)

df.to_csv(OUTPUT, index=False)

print("=" * 65)
print("FIC-PM REVISED LIVE PRIORITY ENGINE")
print("=" * 65)
print("Records:", len(df))
print("Score range:", df["FIC_PM_Score"].min(), "-", df["FIC_PM_Score"].max())
print("\nPriority distribution:")
print(df["Priority_Level"].value_counts().to_string())

print("\nTOP 15")
print(df[[
    "Priority_Rank", "Software_Name", "FIC_PM_Score",
    "Priority_Level", "Anomaly_Detector_Count",
    "Startup_Match_Count", "Prefetch_Match_Count",
    "Metadata_Gap_Count", "Review_Reason"
]].head(15).to_string(index=False))

print("\nOutput:", OUTPUT)
print("Metadata gaps remain visible but do not add score.")
print("This score is a heuristic, not a malware probability.")
