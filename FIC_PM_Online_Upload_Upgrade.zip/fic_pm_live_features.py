﻿import os
import pandas as pd
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "Data")

src = os.path.join(DATA, "live_software.csv")
out = os.path.join(DATA, "live_software_features.csv")

df = pd.read_csv(src)
df = df.fillna("")

# Convert available software metadata into numeric features
df["Name_Length"] = df["Software_Name"].astype(str).str.len()
df["Version_Present"] = df["Version"].astype(str).str.strip().ne("").astype(int)
df["Publisher_Present"] = df["Publisher"].astype(str).str.strip().ne("").astype(int)
df["Install_Date_Present"] = df["Install_Date"].astype(str).str.strip().ne("").astype(int)
df["Install_Location_Present"] = df["Install_Location"].astype(str).str.strip().ne("").astype(int)
df["Registry_Path_Length"] = df["Registry_Path"].astype(str).str.len()
df["HKCU_Source"] = df["Registry_Hive"].astype(str).str.upper().str.contains("HKCU").astype(int)
df["HKLM_Source"] = df["Registry_Hive"].astype(str).str.upper().str.contains("HKLM").astype(int)

numeric = [
    "Name_Length",
    "Version_Present",
    "Publisher_Present",
    "Install_Date_Present",
    "Install_Location_Present",
    "Registry_Path_Length",
    "HKCU_Source",
    "HKLM_Source"
]

df[numeric] = df[numeric].replace([np.inf, -np.inf], np.nan).fillna(0)

df.to_csv(out, index=False)

print("=" * 60)
print("FIC-PM LIVE FEATURE ENGINEERING")
print("=" * 60)
print("Software records:", len(df))
print("Numeric features:", numeric)
print("\nFeature sample:")
print(df[["Software_Name"] + numeric].head(5).to_string(index=False))
print("\nOutput:", out)
print("\nFeature engineering completed.")
