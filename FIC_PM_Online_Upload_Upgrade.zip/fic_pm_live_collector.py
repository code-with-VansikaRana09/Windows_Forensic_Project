﻿import os
import csv
import platform
import datetime

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "Data")
os.makedirs(DATA, exist_ok=True)

NOW = datetime.datetime.now().astimezone().isoformat()
IS_WINDOWS = platform.system() == "Windows"

def save_csv(filename, rows, columns):
    path = os.path.join(DATA, filename)
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)
    print(f"{filename}: {len(rows)} records")

software, usb, startup, prefetch = [], [], [], []

if IS_WINDOWS:
    import winreg

    # Software inventory from uninstall Registry keys
    uninstall_paths = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
    ]

    for root, path in uninstall_paths:
        hive_name = "HKLM" if root == winreg.HKEY_LOCAL_MACHINE else "HKCU"
        try:
            with winreg.OpenKey(root, path) as key:
                count = winreg.QueryInfoKey(key)[0]
                for i in range(count):
                    try:
                        subname = winreg.EnumKey(key, i)
                        with winreg.OpenKey(root, path + "\\" + subname) as sub:
                            def getval(name):
                                try:
                                    return winreg.QueryValueEx(sub, name)[0]
                                except OSError:
                                    return ""

                            name = getval("DisplayName")
                            if not name:
                                continue

                            software.append({
                                "Software_Name": name,
                                "Version": getval("DisplayVersion"),
                                "Publisher": getval("Publisher"),
                                "Install_Date": getval("InstallDate"),
                                "Install_Location": getval("InstallLocation"),
                                "Registry_Hive": hive_name,
                                "Registry_Path": path + "\\" + subname,
                                "Collection_Time": NOW
                            })
                    except OSError:
                        continue
        except OSError:
            continue

    # USB storage device history
    usb_path = r"SYSTEM\CurrentControlSet\Enum\USBSTOR"
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, usb_path) as key:
            count = winreg.QueryInfoKey(key)[0]
            for i in range(count):
                try:
                    device_type = winreg.EnumKey(key, i)
                    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, usb_path + "\\" + device_type) as dk:
                        subcount = winreg.QueryInfoKey(dk)[0]
                        for j in range(subcount):
                            try:
                                serial = winreg.EnumKey(dk, j)
                                usb.append({
                                    "Device_Name": device_type.replace("&", " "),
                                    "Vendor_ID": "",
                                    "Product_ID": "",
                                    "Serial_Number": serial,
                                    "Device_Type": "USB Storage",
                                    "Registry_Path": usb_path + "\\" + device_type + "\\" + serial,
                                    "First_Seen": "",
                                    "Last_Seen": "",
                                    "Device_Status": "Recorded",
                                    "Collection_Time": NOW
                                })
                            except OSError:
                                continue
                except OSError:
                    continue
    except OSError:
        pass

    # Startup Run and RunOnce entries
    startup_paths = [
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", "HKCU_Run"),
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\RunOnce", "HKCU_RunOnce"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run", "HKLM_Run"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\RunOnce", "HKLM_RunOnce"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run", "HKLM_Run_32"),
    ]

    for root, path, location in startup_paths:
        try:
            with winreg.OpenKey(root, path) as key:
                count = winreg.QueryInfoKey(key)[1]
                for i in range(count):
                    try:
                        name, data, value_type = winreg.EnumValue(key, i)
                        startup.append({
                            "Location": location,
                            "Registry_Path": path,
                            "Value_Name": name,
                            "Value_Data": str(data),
                            "Value_Type": value_type,
                            "Collection_Time": NOW
                        })
                    except OSError:
                        continue
        except OSError:
            continue

    # Prefetch inventory only (not parsing contents)
    pf_dir = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Prefetch")
    try:
        for file in os.listdir(pf_dir):
            if file.upper().endswith(".PF"):
                full = os.path.join(pf_dir, file)
                prefetch.append({
                    "File_Name": file,
                    "File_Path": full,
                    "File_Size": os.path.getsize(full),
                    "Last_Modified": datetime.datetime.fromtimestamp(
                        os.path.getmtime(full)
                    ).astimezone().isoformat(),
                    "Collection_Time": NOW
                })
    except OSError:
        print("Prefetch directory unavailable. Permission may be restricted.")

save_csv("live_software.csv", software, [
    "Software_Name", "Version", "Publisher", "Install_Date",
    "Install_Location", "Registry_Hive", "Registry_Path", "Collection_Time"
])

save_csv("live_usb.csv", usb, [
    "Device_Name", "Vendor_ID", "Product_ID", "Serial_Number",
    "Device_Type", "Registry_Path", "First_Seen", "Last_Seen",
    "Device_Status", "Collection_Time"
])

save_csv("live_startup.csv", startup, [
    "Location", "Registry_Path", "Value_Name", "Value_Data",
    "Value_Type", "Collection_Time"
])

save_csv("live_prefetch_inventory.csv", prefetch, [
    "File_Name", "File_Path", "File_Size", "Last_Modified", "Collection_Time"
])

print("\nLive collection completed.")
print("Collection is observational; it does not determine maliciousness.")
