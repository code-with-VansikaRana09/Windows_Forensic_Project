@echo off
cd /d "%~dp0"
echo Installing FIC-PM dependencies...
py -m pip install -r requirements.txt
if errorlevel 1 (
 echo Dependency installation failed.
 pause
 exit /b 1
)
echo.
echo FIC-PM dependencies installed successfully.
pause
